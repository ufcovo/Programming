#ifndef LINKEDSTACK_H
#define LINKEDSTACK_H

#include <iostream>
#include <cassert>

using namespace std;

template <class T>
struct node {
    T info;
    node<T> *link;
};

template <class T>
class LinkedStack {
private:
    node<T> *top;

public:
    LinkedStack() {
        top = NULL;
    }

    ~LinkedStack() {
        destroy();
    }

    bool isEmpty() {
        return (top == NULL);
    }
    
    void push(const T& item) {
        node<T> *newNode = new node<T>;
        newNode->info = item;
        newNode->link = top;
        top = newNode;
    }

    void destroy() {
        node<T> *temp;

        while (top != NULL) {
            temp = top;
            top = top->link;
            delete temp;
        }
    }

    T showTop() {
        assert(!isEmpty());
        return (top->info);
    }

    T pop() {
        assert(!isEmpty());

        node<T> *p;
        T item;
        p = top;
        top = top->link;
        item = p->info;
        delete p;
        return item;
    }
};

#endif