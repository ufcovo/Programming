#ifndef RECURSIVE_H
#define RECURSIVE_H

#include <iostream>

using namespace std;

int fact(int num)
{
    if (num == 0) {
        return 1;
    } else {
        return num * fact(num - 1);
    }
}

int power(int a, int n)
{
    if (n == 0) {
        return 1;
    } else {
        return a * power(a, n - 1);
    }
}

int mult(int x, int y)
{
    if (y < 0) {
        return -(mult(x, -y));
    } else if (y == 0) {
        return 0;
    } else if (y == 1) {
        return x;
    } else {
        return x + mult(x, y - 1);
    }
}

int maximum(int arr[], int index, int size)
{
    int max;

    if (index == size - 1) {
        return arr[index];
    } else {
        max = maximum(arr, index + 1, size);

        if (max < arr[index]) {
            return arr[index];
        }else {
            return max;
        }
    }
}

int fib(int n)
{
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return fib(n - 2) + fib(n - 1);
    }
}

void displayMsgFwd(int n)
{
    if (0 < n) {
        displayMsgFwd(n - 1);
    }

    cout << n << " ";
}

void displayMsgAft(int n)
{
    cout << n << " ";

    if (0 < n) {
        displayMsgAft(n - 1);
    }
}

void displayMsgBoth(int n)
{
    cout << n << " ";

    if (0 < n) {
        displayMsgBoth(n - 1);
    }

    cout << n << " ";
}

void decToBase(int num, int base)
{
    if (0 < num) {
        decToBase(num / base, base);
        cout << num % base;
    }
}

void fun(int n)
{
    if (n) {
        fun(n / 4);
    } else if ((n % 2) == 0) {
        cout << n << endl;
    } else if (0 < n) {
        fun(n - 1);
        cout << n << endl;
    }
}

void atm(int money)
{
    if (50 <= money) {
        cout << "50TL ";
        atm(money - 50);
    } else if (10 <= money) {
        cout << "10TL ";
        atm(money - 10);
    } else if (1 <= money) {
        cout << "1TL ";
        atm(money - 1);
    }
}

void guess(int n)
{
    if (0 < n) {
        cout << n << " ";
        guess(n--);
        cout << endl << n;
    }
}

#endif