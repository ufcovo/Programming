#ifndef POSTEXP_H
#define POSTEXP_H

#include <string>
#include "LinkedStack.h"

using namespace std;

bool validOperand(char c)
{
    return (('0' <= c) && (c <= '9'));
}

float eval(float a, float b, char c)
{
    switch (c) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        default: assert(0);
    }

    return 0;
}

int calc(string expr)
{
    LinkedStack<float> st;
    float x, y;
    char ch;

    for (int i = 0; i < expr.length(); i++) {
            ch = expr[i];

        if (validOperand(ch)) {
            st.push((float)(ch - '0'));
        } else {
            y = st.pop();
            x = st.pop();

            st.push(eval(x, y, ch));
        }
    }

    cout << "Result: " << st.pop() << endl;

    return 0;
}

#endif