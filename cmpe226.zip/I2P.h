#ifndef I2P_H
#define I2P_H

#include <iostream>
#include <string>
#include <cctype>
#include "LinkedStack.h"
#include "PostExp.h"

bool prec(char a, char b)
{
    return !((a == '+'|| a == '-') && ((b == '*'|| b == '/')));
}

int I2P()
{
    LinkedStack<char> oper;
    string input, expr;
    char ch;
    
    cout << "Enter expression: ";
    cin >> input;

    for (int i = 0; i < input.length(); i++) {
        ch = input[i];

        if (isalnum(ch)) {
            expr += ch;
        } else {
            if (!oper.isEmpty() && prec(oper.showTop(), ch)) {
                expr += oper.pop();
            }

            oper.push(ch);
        }
    }

    while (!oper.isEmpty()) {
        expr += oper.pop();
    }

    cout << "Expr:\t" << expr << endl; 
    return calc(expr);
}

#endif