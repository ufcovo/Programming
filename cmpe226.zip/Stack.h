#ifndef RECURSIVE_H
#define RECURSIVE_H

#include <iostream>
#include <cassert>

template <class T>
class Stack {
private:
    T *arr;
    int top;
    int size;

public:
    Stack(int = 100);
    ~Stack();

    bool isEmpty();
    bool isFull();

    void destroy();
    void push(const T&);

    T pop();
    T showTop();
};

template <class T>
Stack<T>::Stack(int stackSize)
{
    size = stackSize;
    top = 0;
    arr = new T[size];
}

template <class T>
Stack<T>::~Stack()
{
    delete[] arr;
}

template <class T>
bool Stack<T>::isEmpty()
{
    return (top == 0);
}

template <class T>
bool Stack<T>::isFull()
{
    return (top == size);
}

template <class T>
void Stack<T>::destroy()
{
    top = 0;
}

template <class T>
void Stack<T>::push(const T& item)
{
    if (!isFull()) {
        arr[top++] = item;
    } else {
        cerr << "Stack is full." << endl;
    }
}

template <class T>
T Stack<T>::pop()
{
    assert(!isEmpty());
    return arr[--top];
}

template <class T>
T Stack<T>::showTop()
{
    assert(!isEmpty());
    return arr[top - 1];
}

#endif