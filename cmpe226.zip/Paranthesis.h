#ifndef PARANTHESIS_H
#define PARANTHESIS_H

#include <iostream>
#include <string>
#include "Stack.h"

using namespace std;

int check()
{
    Stack<char> par;
    string expr;
    char next, x;
    bool valid = true;

    cout << "Enter mathematical expression:";
    cin >> expr;

    for (int i = 0; valid && i < expr.length(); i++) {
        next = expr[i];

        if (next == '(') {
            par.push(next);
        } else if (next == ')') {
            if (par.isEmpty) {
                valid = false;
            } else {
                x = par.pop();
            }
        }
    }

    if (!par.isEmpty()) {
        valid = false;
    }

    if (valid) {
        cout << "Correct parantheses.";
    } else {
        cout << "Incorrect parantheses.";
    }
}

#endif